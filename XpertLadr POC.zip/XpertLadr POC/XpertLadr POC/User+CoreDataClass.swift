//
//  User+CoreDataClass.swift
//  XpertLadr POC
//
//  Created by Sireesha Siddineni on 21/07/20.
//  Copyright © 2020 Sireesha Siddineni. All rights reserved.
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
