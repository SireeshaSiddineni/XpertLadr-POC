//
//  EncryptionTransformer.swift
//  XpertLadr POC
//
//  Created by Sireesha Siddineni on 21/07/20.
//  Copyright © 2020 Sireesha Siddineni. All rights reserved.
//

import Foundation

class EncryptionTransformer: ValueTransformer {
    
    override class func allowsReverseTransformation() -> Bool{
        return true
    }
    override func transformedValue(_ value: Any?) -> Any?{
        guard let date = value as? Date else {return nil}
        
        return date.stringlize().data(using: .utf8)?.base64EncodedData()
    }
    
    override func reverseTransformedValue(_ value: Any?) -> Any?{
        guard let data = value as? Data, let decoded = Data(base64Encoded: data) else {return nil}
        
        return String(data: decoded, encoding: .utf8)?.datelize()
    }
}


extension Date {
    func stringlize() -> String {
        let formater = DateFormatter()
        formater.dateFormat = "yyyyMMddss"
        return formater.string(from: self)
    }
}

extension String {
    func datelize() -> Date? {
        let formater = DateFormatter()
        formater.dateFormat = "yyyyMMddss"
        return formater.date(from: self)
    }
}
