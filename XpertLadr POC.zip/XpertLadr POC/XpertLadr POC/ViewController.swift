//
//  ViewController.swift
//  XpertLadr POC
//
//  Created by Sireesha Siddineni on 20/07/20.
//  Copyright © 2020 Sireesha Siddineni. All rights reserved.
//

import UIKit
import CoreData


class ViewController: UIViewController {
    
    var people: [NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        CoreDataManager.shared.set([1,2,3,4], forKey: "key1")
        print("array stored for key1 = \(CoreDataManager.shared.array(id: "key1"))")
        
        CoreDataManager.shared.set(45, forKey: "key2")
        print("intvalue stored for key2 = \(CoreDataManager.shared.int(id: "key2"))")
        
        CoreDataManager.shared.set("Sireesha", forKey: "key3")
        print("String stored for key3 = \(CoreDataManager.shared.string(id: "key3"))")
        
        CoreDataManager.shared.set(45.7689, forKey: "key4")
        print("Floatvalue stored for key4 = \(CoreDataManager.shared.float(id: "key4"))")
               
        CoreDataManager.shared.set(789.767890, forKey: "key5")
        print("doublevalue stored for key5 = \(CoreDataManager.shared.double(id: "key5"))")
        
        CoreDataManager.shared.set(true, forKey: "key6")
        print("boolvalue stored for key6 = \(CoreDataManager.shared.bool(id: "key6"))")
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchAllUsers()
    }
    
    func fetchAllUsers(){
        
        if CoreDataManager.shared.fetchAllUsers() != nil{
            
            people = CoreDataManager.shared.fetchAllUsers()!
            
        }
        
    }
}
