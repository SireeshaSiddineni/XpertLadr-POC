//
//  CoreDataManager.swift
//  XpertLadr POC
//
//  Created by Sireesha Siddineni on 21/07/20.
//  Copyright © 2020 Sireesha Siddineni. All rights reserved.
//

import Foundation
import CoreData
import UIKit
import CryptoSwift

class CoreDataManager {
    
    static let shared = CoreDataManager()
    private init() {}
    
    lazy var persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "XpertLadr_POC")
        
        
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    func saveContext () {
        let context = CoreDataManager.shared.persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    //Getter Methods
    func get(id: String) -> String {
        let context = CoreDataManager.shared.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "User")
        
        fetchRequest.predicate = NSPredicate(format: "id == %@" ,id)
        
        do {
            let fetchResults =  try context.fetch(fetchRequest)
            
            for Entity in fetchResults as [NSManagedObject] {
                
                let entity1 = Entity.value(forKey: "name")
                let aesD:Array<UInt8> = entity1 as! Array<UInt8>
        
                let aes = try AES(key: "1234567890123456", iv: "abdefdsrfjdirogf")

                let aesFinal = (try? aes.decrypt(aesD))!
                let decrypted = String(bytes: aesFinal, encoding: .utf8)
                
                return decrypted!
                
            }
        }catch{
            print(error.localizedDescription)
            return ""
        }
        return ""
    }
    func bool(id:String) -> Bool {
        return Bool(get(id: id))!
    }
    func int(id:String) -> Int{
        return Int(get(id: id))!
    }
    func double(id:String) -> Double {
        return Double(get(id: id))!
    }
    func float(id:String) -> Float {
        return Float(get(id: id))!
    }
    func array(id:String) -> Array<Any> {
        let x = get(id: id)
        let test = String(x.filter { !"[], ".contains($0) })
        return Array(test)
    }
    func string(id:String) -> String {
        return get(id: id) 
    }
    func stringFromAny(_ value:Any?) -> String {
        if let nonNil = value, !(nonNil is NSNull) {
            return String(describing: nonNil)
        }
        return ""
    }
    func set(_ name: Any, forKey : String)  {
        let str = stringFromAny(name)
        if let aes = try? AES(key: "1234567890123456", iv: "abdefdsrfjdirogf"),

            let aesE = try? aes.encrypt(Array(str.utf8)) {
          
        let result = sameValueExists(id: forKey)
        if result {
            update(name: aesE, id:forKey)
        }else{
            insertUser(aesE, id : forKey)
        }
        }
    }
    
    func set(_ name: Float, forKey : String)  {
        if let aes = try? AES(key: "1234567890123456", iv: "abdefdsrfjdirogf"),
          let aesE = try? aes.encrypt(Array(String(name).utf8)) {
          //print("AES encrypted: \(aesE)")
        let result = sameValueExists(id: forKey)
        if result {
            update(name: aesE, id:forKey)
        }else{
            insertUser(aesE, id : forKey)
        }
        }
    }
    func set(_ name: Double, forKey : String)  {
        if let aes = try? AES(key: "1234567890123456", iv: "abdefdsrfjdirogf"),
          let aesE = try? aes.encrypt(Array(String(name).utf8)) {
         // print("AES encrypted: \(aesE)")
        let result = sameValueExists(id: forKey)
        if result {
            update(name: aesE, id:forKey)
        }else{
            insertUser(aesE, id : forKey)
        }
        }
    }
    
    func set(_ name: Int, forKey : String)  {
       if let aes = try? AES(key: "1234567890123456", iv: "abdefdsrfjdirogf"),
          let aesE = try? aes.encrypt(Array(String(name).utf8)) {
         //print("AES encrypted: \(aesE)")
        let result = sameValueExists(id: forKey)
        if result {
            update(name: aesE, id:forKey)
        }else{
            insertUser(aesE, id : forKey)
        }
        }
    }
    
    func set(_ name: String, forKey : String)  {
     if let aes = try? AES(key: "1234567890123456", iv: "abdefdsrfjdirogf"),
          let aesE = try? aes.encrypt(Array(name.utf8)) {
          //print("AES encrypted: \(aesE)")
        let result = sameValueExists(id: forKey)
        if result {
            update(name: aesE, id:forKey)
        }else{
            insertUser(aesE, id : forKey)
        }
        }
    }
    
    func set (_ name: Bool, forKey : String)  {
        if let aes = try? AES(key: "1234567890123456", iv: "abdefdsrfjdirogf"),
          let aesE = try? aes.encrypt(Array(String(name).utf8)) {
         // print("AES encrypted: \(aesE)")
        let result = sameValueExists(id: forKey)
        if result {
            update(name: aesE, id:forKey)
        }else{
            insertUser(aesE, id : forKey)
        }
        }
    }
    func sameValueExists(id: String) -> Bool {
        let managedContext = CoreDataManager.shared.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        let predicate = NSPredicate(format: "id == %@", id)
        request.predicate = predicate
        request.fetchLimit = 1
        
        do{
            let count = try managedContext.count(for: request)
            if(count == 0){
                return false
            }
            else{
                return true
            }
        }
        catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
            return true
        }
    }
    func insertUser(_ name: Any, id : String) {
        let managedContext = CoreDataManager.shared.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "User",
                                                in: managedContext)!
        let user = NSManagedObject(entity: entity,
                                   insertInto: managedContext)
        
        
        user.setValue(name, forKeyPath: "name")
        user.setValue(id, forKeyPath: "id")
        
        do {
            try managedContext.save()
            
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
            
        }
    }
    
    func update(name: Any, id : String) {
        
        let context = CoreDataManager.shared.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "User")
        
        fetchRequest.predicate = NSPredicate(format: "id == %@" ,id)
        do
        {
            let test = try context.fetch(fetchRequest)
            
            let objectUpdate = test[0]
            objectUpdate.setValue(name, forKey: "name")
            objectUpdate.setValue(id, forKey: "id")
            do{
                try context.save()
                
            }
            catch
            {
                print(error)
                
            }
        }
        catch
        {
            print(error)
            
        }
    }
  
    func fetchAllUsers() -> [User]?{
        let managedContext = CoreDataManager.shared.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "User")
        
        do {
            let people = try managedContext.fetch(fetchRequest)
            return people as? [User]
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
    }
    
  /* commenting the delete functiions
     func delete(user : User){
      
      let managedContext = CoreDataManager.shared.persistentContainer.viewContext
      
      do {
          
          managedContext.delete(user)
          
      } catch {
          print(error)
      }
      
      do {
          try managedContext.save()
      } catch {
          print(error)
      }
  }
     func delete(id: String) -> [User]? {
        
        let managedContext = CoreDataManager.shared.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "User")
        
        fetchRequest.predicate = NSPredicate(format: "id == %@" ,id)
        do {
            let item = try managedContext.fetch(fetchRequest)
            var arrRemovedPeople = [User]()
            for i in item {
                managedContext.delete(i)
                
                try managedContext.save()
                
                arrRemovedPeople.append(i as! User)
            }
            return arrRemovedPeople
            
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
        
    }*/
}

